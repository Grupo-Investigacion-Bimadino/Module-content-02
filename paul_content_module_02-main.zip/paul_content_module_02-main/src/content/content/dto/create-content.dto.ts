export class CreateContentDto {}
