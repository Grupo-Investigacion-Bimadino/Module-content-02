export class Multimedia {}
