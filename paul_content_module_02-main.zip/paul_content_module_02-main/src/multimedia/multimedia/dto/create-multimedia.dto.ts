export class CreateMultimediaDto {}
