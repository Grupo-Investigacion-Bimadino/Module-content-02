export class CreateLabelDto {}
